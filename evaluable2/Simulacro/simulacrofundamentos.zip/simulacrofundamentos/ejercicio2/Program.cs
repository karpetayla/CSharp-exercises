﻿using System;

class Program
{
    static void Main()
    {
    /*Desarrolla un programa en C# que permita a un concesionario ingresar las ventas mensuales de
    coches y realizar un análisis básico. El programa debe:
    • Crear una lista para almacenar el número de coches vendidos en cada mes.
    // ejemplo de Lista con las ventas de los 12 meses
    List<int> ventas = new List<int> { 45, 52, 38, 61, 73, 82, 91, 78,
    64, 55, 47, 39 };
    • Pedir al usuario que ingrese las ventas mes por mes, asegurándose de que cada valor
    sea un número entero no negativo.
    Una vez ingresadas todas las ventas, el programa debe calcular y mostrar:
    • El promedio de coches vendidos por mes.
    • El mes con mayores ventas (número del mes y cantidad vendida).
    • El mes con menores ventas (número del mes y cantidad vendida).
    • El total de coches vendidos en todo el período.

    Ejercicio 3: Sistema de Registro de Coches en Taller (3.5 puntos)
    Crea un programa en C# que implemente un sistema simple de registro de coches en un taller
    mecánico utilizando una base de datos MySQL. El programa debe permitir al usuario agregar
    nuevos coches a la base de datos y listar todos los coches registrados.
    Primero, necesitarás crear la base de datos y la tabla. Utiliza los siguientes comandos SQL:
    CREATE DATABASE taller;
    USE taller;
    CREATE TABLE coches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    anio INT,
    matricula VARCHAR(10) NOT NULL);
    El programa en C# debe:
    Presentar un menú al usuario con las siguientes opciones:
    1. Agregar un nuevo coche
    2. Listar todos los coches
    3. Salir del programa
    Para la opción "Agregar un nuevo coche":
    • Solicitar al usuario que ingrese la marca, el modelo, el año y la matrícula del coche.
    • Insertar estos datos en la tabla coches de la base de datos.
    • Mostrar un mensaje de confirmación.
    Para la opción "Listar todos los coches":
    • Realizar una consulta SELECT a la base de datos para obtener todos los coches
    registrados.
    • Mostrar la información de cada coche en un formato legible (por ejemplo: "ID: 1 |
    Marca: Seat | Modelo: Ibiza | Año: 2020 | Matrícula: 1234ABC").*/

    }
}